<?php
$config = array(
    array(
        'field' => 'text_field',
        'label' => 'Text Field One',
        'rules' => 'required'
    ),
    array(
        'field' => 'min_text_field',
        'label' => 'Text Field Two',
        'rules' => 'required'
    ),
    array(
        'field' => 'max_text_field',
        'label' => 'Text Field Three',
        'rules' => 'required'
    )
);