<?php include_once('logged_header.php'); ?>
	<h1></h1>
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<img src="<?php echo base_url('application/assets/images/.png'); ?>" class="img-responsive" alt="" />
			</div>
			<div class="col-md-6">
				<img src="<?php echo base_url('application/assets/images/nurse.png'); ?>" class="img-responsive" alt="Sexual abuse doesnot always involve force and maynot leave visible injuries" style="width:300px;height:450px;"/>
			</div>
		</div>
	</div>
<?php include_once('logged_footer.php'); ?>