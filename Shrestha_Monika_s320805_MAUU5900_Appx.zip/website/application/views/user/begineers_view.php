<?php include_once('logged_header.php'); ?>
	<!--<div>
		<?php foreach($checkscore as $row): ?>  
			<p>Begineers view<?=$row->score?></p>
		<?php endforeach; ?>
	</div>-->
	<div class="container">
		<h1 style="font-family:arial;">Sexual Awareness</h1>
		<br>
		<div class="container">
			<div class="embed-responsive embed-responsive-16by9">
				<iframe width="1080" height="700" src="https://www.youtube.com/embed/uauWIruITpw" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			</div>
		</div>
	</div>
<?php include_once('logged_footer.php'); ?>