<?php include_once('logged_header.php'); ?>
<?php include_once('quiz.php'); ?>

