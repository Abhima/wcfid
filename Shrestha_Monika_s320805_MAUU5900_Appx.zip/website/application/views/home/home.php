<?php include('home_header.php'); ?>
	<!--<div class="container embed-responsive embed-responsive-16by9">
		<div id="myCarousel" class="carousel slide" data-ride="carousel">
		    <!-- Indicators -->
		    <!--<ol class="carousel-indicators">
		      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
		      <li data-target="#myCarousel" data-slide-to="1"></li>
		      <li data-target="#myCarousel" data-slide-to="2"></li>
		    </ol>
		    <!-- Wrapper for slides -->
		   <!-- <div class="carousel-inner">
		      <div class="item active">
		        <img src="application/assets/images/woman.png" alt="Los Angeles" style="width:1350px; height:550px">
		        <div class="carousel-caption">
			        <h3></h3>
			        <p></p>
			    </div>
		      </div>

		      <div class="item">
		        <img src="application/assets/images/cover.jpg" alt="Chicago" style="width:1350px; height:550px">
		        <div class="carousel-caption">
			        <h3></h3>
			        <p></p>
			    </div>
		      </div>
		    
		      <div class="item">
		        <img src="application/assets/images/cover.jpg" alt="New york" style="width:1350px; height:550px">
		        <div class="carousel-caption">
			        <h3></h3>
			        <p></p>
			    </div>
		      </div>
		    </div>
		    <!-- Left and right controls -->
		    <!--<a class="left carousel-control" href="#myCarousel" data-slide="prev">
		      <span class="glyphicon glyphicon-chevron-left"></span>
		      <span class="sr-only">Previous</span>
		    </a>
		    <a class="right carousel-control" href="#myCarousel" data-slide="next">
		      <span class="glyphicon glyphicon-chevron-right"></span>
		      <span class="sr-only">Next</span>
		    </a>
	  </div>
	</div>-->
	<div class="container">
		<div class="row">
			<div class="col-md-9">
				<h2>What is sexual abuse?</h2>
					<p style="font-family:arial; font-size:120%;">&nbsp Sexual abuse means any kind of sexual contact (involving 2 or more people) that is forced, or without their consent or to someone who cannot consent.</p>
				<h2>What is consent?</h2>
					<p style="font-family:arial; font-size:120%;">&nbsp Consent means you agree and understand what you are agreeing to. In South Africa, the age of consent for sexual touching or sexual intercourse is 16 years. You cannot give consent to sex if you are drugged, unconscious, under the age of 12 years or you have a mental disability of such a severity you can not understand the nature of the sexual act, the possible risks, or communicate that you do not want to take part.</p>
				<h2>Can an adult with intellectual disability consent?</h2>
					<p style="font-family:arial; font-size:120%;">&nbsp Most adults with a mild and some with a moderate intellectual disability will be able to consent to a sexual relationship with sexuality education and support. However, adults with a severe or profound intellectual disability cannot tell the difference between affectionate touch or sexual touch.</p>
			</div>
			<div class="col-md-3">
	            <img src="<?php echo base_url('application/assets/images/buggy.jpg'); ?>" class="img-responsive" alt="Child with intellectual disability" style="width:450px; height:350px"/>
			</div>
		</div>
		<div>
			<h2>Different Kinds of abuses</h2>
				<p style="font-family:arial; font-size:120%;"> Abuse can also be emotional, physical, through neglect or financial. <br><br>
					<b>1. Emotional abuse:</b> Frequently criticizing, swearing, threatening, not meeting emotional needs.<br>
					<b>&nbsp Look for:</b> withdrawal and a sad mood that does not easily change.<br><br>
					<b>2. Physical abuse:</b>Deliberately causing physical harm through; hitting, kicking, slapping, shaking, burning or scalding – burns made by hot water.<br>
					<b>&nbsp Look for:</b> unexplained fractures (broken bones), burns, or bruising, especially bruising at different stages of healing. Watch for a child or adult who seems fearful, startles easily, or freezes (sudden stiffening of the body).
				</p>
		</div>
	</div>
<?php include('home_footer.php'); ?>